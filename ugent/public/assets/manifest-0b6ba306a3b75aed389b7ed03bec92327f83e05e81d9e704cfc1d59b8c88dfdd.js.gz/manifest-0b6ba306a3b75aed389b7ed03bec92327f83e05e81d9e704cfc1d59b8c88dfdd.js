



// We use Webpacker to manage our JS, so removed the '=' sign here to tell
// Sprockets to ignore JS
// link_directory ../javascripts .js;
